NovaChat
========

A responsive front-end chat website demo.

How to use:
1. Extract the ZIP file.
2. Open index.html in Chrome or another modern browser.
3. Select a contact and send messages.

Messages are saved in this browser using localStorage. This is a front-end demo:
messages are NOT delivered to other people or synced between devices. Real multi-user
chat requires a backend and user authentication (for example, Firebase or Supabase).
